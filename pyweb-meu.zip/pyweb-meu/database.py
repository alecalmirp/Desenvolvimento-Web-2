import sqlite3

# Classe utilitária para ajudar na inicialização do banco de dados.

class Database:

    @staticmethod
    def get_connection(): # Obter uma conexão com o BD
        conn = sqlite3.connect ('BancoDeDadosAula.db')
        return conn
    
    @staticmethod
    def create_db(): # Criar as tabelas
        conn = Database.get_connection()
        with open('schema.sql') as f:
            # Executa o create table, insert, ...
            conn.executescript(f.read())
        conn.commit()
        conn.close()


if __name__ == '__main__':
    Database.create_db()