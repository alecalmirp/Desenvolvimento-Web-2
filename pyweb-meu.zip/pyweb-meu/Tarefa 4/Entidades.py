class Cliente:

    def __init__ (self, nome, email, cpf=None, cep=None, id=None):
    #telefone, senha, confirmacao, dataDeNascimento, email, 
        self.nome = nome
        self.email = email
        self.cpf = cpf
        self.cep = cep
        self.id = id

class Produto:

    def __init__(self, nome, categoria, preco, id = None):
        self.id = id
        self.categoria = categoria # "AMD"
        self.nome = nome # "Processador AMD Ryzen R5 3600"
        self.preco = preco # 121.00

class Favorito:

    def __init__(self, idProduto, idCliente, id=None):
        self.id = id
        self.idProduto = idProduto
        self.idCliente = 1






