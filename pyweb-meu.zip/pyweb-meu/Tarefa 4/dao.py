from database import Database

# dao = Data Access object | Implementa a conexão com o banco

class produtoDao:

    def insertCsv(self):
        import csv
        from Entidades import Produto
        p = produtoDao()
        with open ("lista-500.csv") as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count != 0:
                    produto = Produto(row[1], row[2], row[3])
                    p.save(produto)
                line_count += 1

    def save(self, produto):
        conn = Database.get_connection()
        conn.execute(
            f"""
            INSERT INTO produto (
                nome, categoria, preco
                ) VALUES (?, ?, ?)
            """,
            (
                produto.nome, produto.categoria, produto.preco
            )
        )
        conn.commit()
        conn.close()

    def find_all(self):
        conn = Database.get_connection()

        res = conn.execute ("SELECT id, nome, categoria, preco FROM produto")

        result = res.fetchall()

        result = [
            {
                "id": produto[0],
                "nome": produto[1],
                "categoria": produto[2],
                "preco": produto[3],
            }for produto in result]

        conn.close()

        return result

    def update (self, produto):
        conn = Database.get_connection()
        conn.execute (
            """
            UPDATE produto SET nome = ?, categoria = ?, preco = ?
            WHERE id = ?
            """,
            (
                produto.nome,
                produto.categoria,
                produto.preco,
                produto.id
            )
        )
        conn.commit()
        conn.close()

    def delete (self, id):
        conn = Database.get_connection()
        conn.execute (
            f"""
            DELETE FROM produto WHERE id = {id}
            """
        )
        conn.commit()
        conn.close()

    def get_produto (self, id):
        conn = Database.get_connection()
        res = conn.execute (
            f"""
            SELECT id, nome, categoria, preco FROM produto WHERE id = {id}
            """
        )
        result = res.fetchone()

        from Entidades import Produto

        produto = Produto(result[1], result[2], result[3], id = result[0])

        conn.close()

        return produto

    def pesquisa (self, pesquisa):
        conn = Database.get_connection()
        res = conn.execute (f"SELECT nome, categoria, preco, id FROM produto WHERE nome LIKE '%{pesquisa}%'")
        result = res.fetchall()

        from Entidades import Produto

        result = [
            {
                "nome": produto[0],
                "categoria": produto[1],
                "preco": produto[2],
                "id": produto[3]
            }for produto in result]

        conn.close()

        return result

class favoritosDao:

    def favoritar (self, favorito):
        conn = Database.get_connection()

        res = conn.execute (f"SELECT * FROM favoritos WHERE idProduto = {favorito.idProduto}")

        result = res.fetchone()

        if result:
            conn.close()
            return result
        
        conn.execute(f"""
            INSERT INTO favoritos (
                idProduto, idCliente
                ) VALUES (?, ?)
            """,
            (
                favorito.idProduto, favorito.idCliente
            )
        )
        conn.commit()
        conn.close()
        return "Sucesso"

    def desfavoritar (self, id):
        conn = Database.get_connection()
        conn.execute (
            f"""
            DELETE FROM favoritos WHERE id = {id}
            """
        )
        conn.commit()
        conn.close()

    def find_all(self, idCliente):
        conn = Database.get_connection()

        res = conn.execute(f"""SELECT p.nome, p.categoria, p.preco, p.id, f.id, f.idCliente
                                FROM produto AS p INNER JOIN favoritos AS f ON
                                p.id = f.idProduto WHERE f.idCliente = {idCliente}""")

        result = res.fetchall()

        result = [
            {
                "nome": produto[0],
                "categoria": produto[1],
                "preco": produto[2],
                "idProduto": produto[3],
                "id": produto[4],
                "idCliente": produto[5]
            }for produto in result]

        conn.close()

        return result

    def pesquisa (self, pesquisa, idCliente):
        conn = Database.get_connection()
        res = conn.execute (f"""SELECT p.nome, p.categoria, p.preco, p.id, f.id 
                                FROM produto AS p INNER JOIN favoritos AS f ON
                                p.id = f.idProduto WHERE p.nome LIKE '%{pesquisa}%'
                                AND f.idCLiente = {idCliente}""")
        result = res.fetchall()

        result = [
            {
                "nome": produto[0],
                "categoria": produto[1],
                "preco": produto[2],
                "idProduto": produto[3],
                "id": produto[4]
            }for produto in result]

        conn.close()

        return result

class clienteDao:

    def save (self, cliente):
        conn = Database.get_connection()
        conn.execute(
            f"""
            INSERT INTO cliente (
                nome, email, cpf, cep
                ) VALUES (?, ?, ?, ?)
            """,
            (
                cliente.nome, cliente.email, cliente.cpf, cliente.cep
            )
        )
        conn.commit()
        conn.close()

    def delete (self, id):
        conn = Database.get_connection()
        conn.execute (
            f"""
            DELETE FROM cliente WHERE id = {id}
            """
        )
        conn.commit()
        conn.close()

    def update (self, cliente):
        conn = Database.get_connection()
        conn.execute (
            """
            UPDATE cliente SET nome = ?, email = ?, cpf = ?, cep = ?
            WHERE id = ?
            """,
            (
                cliente.nome,
                cliente.email,
                cliente.cpf,
                cliente.cep,
                cliente.id
            )
        )
        conn.commit()
        conn.close()

    #def find_cliente (self, id):
     #   conn = Database.get_connection()
      #  res = conn.execute("SELECT nome, email, cpf, cep FROM cliente WHERE id = {id}")

    def find_all(self):

        conn = Database.get_connection()

        res = conn.execute ("SELECT id, nome, email, cpf, cep FROM cliente")

        result = res.fetchall()

        result = [
            {
                "id": cliente[0],
                "nome": cliente[1],
                "email": cliente[2],
                "cpf": cliente[3],
                "cep": cliente[4]
            }for cliente in result]

        conn.close()

        return result

    def get_cliente (self, id):
        conn = Database.get_connection()
        res = conn.execute (
            f"""
            SELECT nome, email, cpf, cep, id FROM cliente WHERE id = {id}
            """
        )
        result = res.fetchone()

        from Entidades import Cliente

        cliente = Cliente(result[0], result[1], cpf = result[2], cep = result[3], id = result[4])

        conn.close()

        return cliente

if __name__ == '__main__':
    dao = favoritosDao()
    from Entidades import Favorito
    favoritos = Favorito(50, 1)
    teste = dao.find_all()
    print(teste)
    