DROP TABLE IF EXISTS cliente;
DROP TABLE IF EXISTS produto;
DROP TABLE IF EXISTS favoritos;

CREATE TABLE cliente(
    -- Chave Primária --
    id integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    nome text NOT NULL,
    email text NOT NULL,
    cpf text,
    cep text,
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE produto(
    -- Chave Primária --
    id integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    nome text NOT NULL,
    categoria text NOT NULL,
    preco float NOT NULL
    
);

CREATE TABLE favoritos(

    id integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    idProduto integer,
    idCliente integer,
    FOREIGN KEY(idProduto) REFERENCES produto(idProduto),
    FOREIGN KEY(idCliente) REFERENCES cliente(idCliente)
);

INSERT INTO cliente (nome, cpf, cep, email)
VALUES
    ('admin', '1002000', '85850.100', 'admin@test.org'),
    ("Maria Silver", "949.282.111-82", '85850.100', "mariam@test.org"),
    ("Jairo Carlile", "144.217.577-11", '85850.100', "carlile@test.org"),
    ("Marcos Oliva", "433.144.644-52", '85850.100', "marcos@test.org");

