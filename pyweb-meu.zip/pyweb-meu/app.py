from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime
from Entidades import Cliente, Produto, Favorito

# "Flask" é uma classe importada, enquanto o "App" é uma instanciação dessa classe Flask.

app = Flask(__name__)
app.config['SECRET_KEY'] = 'wow1001'

@app.route("/")
def index():
    return render_template ("layout.html")

@app.route("/cotacao", methods=["GET", "POST"])
def cotacao():
    # (GET) usado quando o usuario digita a url no browser.
    if request.method == "GET":
        return render_template ("cotacao.html")
    peso = float(request.form.get("Peso"))
    altura = float(request.form.get("Altura"))
    if (peso > 0 and altura > 0):
        imc = peso/(altura*altura)
    return render_template ("cotacao.html", IMC=round(imc, 2))

@app.route("/formulario", methods=["GET", "POST"])
def formulario():
    if request.method == "GET":
        return render_template ("formulario.html")
    pessoa = None
    Nome = request.form.get("nome")
    cpf = request.form.get("cpf")
    cep = request.form.get("cep")
    Email = request.form.get("email")
    id = request.form.get("id")
    pessoa = Cliente(Nome, Email, cpf=cpf, cep=cep, id = id)
    Nome = ""
    cpf = ""
    cep = ""
    Email = ""
    
    from dao import clienteDao
    dao = clienteDao()

    if id == None:
        dao.save(pessoa)

    if id:
        dao.update(pessoa)
        pessoa = None
        id = None
        return redirect(url_for('displayClientes'))


    pessoa = None


    return render_template ("formulario.html")

@app.route("/formularioProduto", methods=["GET", "POST"])
def formularioProduto():
    if request.method == "GET":
        return render_template ("formularioProduto.html")
    produto = None
    nome = request.form.get("nome")
    categoria = request.form.get("categoria")
    preco = request.form.get("preco")
    id = request.form.get("id")
    produto = Produto(nome, categoria, preco, id = id)
    flash(f'Produto {nome} cadastrado com sucesso!', 'success')
    nome = ""
    categoria = ""
    preco = ""
    
    from dao import produtoDao
    dao = produtoDao()

    if id == None:
        dao.save(produto)

    if id:
        dao.update(produto)
        produto = None
        id = ""
        return redirect(url_for('displayProdutos'))

    produto = None
    id = ""

    return render_template ("formularioProduto.html")

@app.route("/displayClientes", methods=["GET"])
def displayClientes():
    from dao import clienteDao
    dao = clienteDao()
    clientes = dao.find_all()

    return render_template ("displayClientes.html", clientes=clientes)
    

@app.route("/displayProdutos", methods=["GET", "POST"])
def displayProdutos():
    from dao import produtoDao
    dao = produtoDao()
    if request.method == "GET":
        produtos = dao.find_all()
        return render_template ("displayProdutos.html", produtos=produtos)
    pesquisa = request.form.get("pesquisa")
    produtos = dao.pesquisa(pesquisa)
    pesquisa = None
    return render_template ("displayProdutos.html", produtos=produtos)

@app.route ("/displayFavoritos", methods=["GET", "POST"])
def displayFavoritos():
    from dao import favoritosDao, clienteDao
    dao = favoritosDao()
    daoC = clienteDao()
    Cliente = daoC.get_cliente(1)
    if request.method == "GET":
        favoritos = dao.find_all(1)
        return render_template ("displayFavoritos.html", favoritos=favoritos, Cliente=Cliente)
    pesquisa = request.form.get("pesquisa")
    produtos = dao.pesquisa(pesquisa,1)
    pesquisa = None
    return render_template ("displayFavoritos.html", favoritos=produtos, Cliente=Cliente)

@app.route("/delete/<id>", methods=["GET"])
def deleteCliente(id):

    from dao import clienteDao
    dao = clienteDao()
    dao.delete(id)
    flash(f'Cliente {id} removido com sucesso!', 'Success')
    return redirect(url_for('displayClientes'))

@app.route("/deleteProduto/<id>", methods=["GET"])
def deleteProduto(id):

    from dao import produtoDao
    dao = produtoDao()
    dao.delete(id)
    flash(f'Produto {id} removido com sucesso!', 'success')
    return redirect(url_for('displayProdutos'))

@app.route("/editarCliente/<id>", methods=["GET"])
def editarCliente(id):    
    from dao import clienteDao
    dao = clienteDao()
    cli = dao.get_cliente(id)
    return render_template("formulario.html", cli = cli, id = id)

@app.route("/editarProduto/<id>", methods=["GET"])
def editarProduto(id):    
    from dao import produtoDao
    dao = produtoDao()
    prod = dao.get_produto(id)
    return render_template("formularioProduto.html", prod = prod, id = id)

@app.route("/favoritarProduto/<id>", methods=["GET"])
def favoritarProduto(id):
    from dao import favoritosDao
    dao = favoritosDao()
    favoritos = Favorito(id, 1)
    dao.favoritar(favoritos)
    return redirect(url_for('displayProdutos'))

@app.route("/desfavoritarProduto/<id>", methods=["GET"])
def desfavoritarProduto(id):
    from dao import favoritosDao
    dao = favoritosDao()
    dao.desfavoritar(id)
    return redirect(url_for('displayFavoritos'))


@app.route("/opcoes/<sel>", methods=["GET"])
def opcoes(sel):

    if sel == '1':
        from database import Database
        db = Database()
        db.create_db()
        return redirect(url_for('index'))
    if sel == '2':
        from dao import produtoDao
        dao = produtoDao()
        dao.insertCsv()
        return redirect(url_for('displayProdutos'))

if __name__ == "__main__":

    app.run(debug=True)